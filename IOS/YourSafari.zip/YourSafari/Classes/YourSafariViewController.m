//
//  YourSafariViewController.m
//  YourSafari
//
//  Created by SE420701 on 10/25/10.
//  Copyright 2010 Tulsa Community College. All rights reserved.
//

#import "YourSafariViewController.h"

@implementation YourSafariViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	activityIndicator=[[[UIActivityIndicatorView alloc]
						initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray]
					   autorelease];
	[address setLeftView:activityIndicator];
	[address setLeftViewMode:UITextFieldViewModeAlways];
}

-(IBAction)refresh:(id)sender
{
	[webView reload];
}

-(IBAction)forward:(id)sender
{
	[webView goForward];
}

-(IBAction)back:(id)sender
{
	[webView goBack];
}

-(IBAction)stop:(id)sender
{
	[webView stopLoading];
}

-(BOOL)textFieldShouldReturn:(UITextField *)aTextField
{
	[aTextField resignFirstResponder];
    
    NSUInteger rangeLocation=[[aTextField text] rangeOfString:@"http://"].location;
    NSRange range=NSMakeRange(rangeLocation, 7);
    
    NSMutableString *changedUrl;
    int counter =0;
    if (range.location==NSNotFound){
        
        rangeLocation=[[aTextField text] rangeOfString:@"www."].location;
        range=NSMakeRange(rangeLocation, 4);
        if(range.location==NSNotFound){
            changedUrl = [NSString stringWithFormat:@"http://www.%@",[aTextField text]];
            counter=1;
        }
        else{
            changedUrl = [NSString stringWithFormat:@"http://%@",[aTextField text]];
            counter=1;
        }
    }
    rangeLocation=[[aTextField text] rangeOfString:@".com"].location;
    range=NSMakeRange(rangeLocation, 4);
    if(range.location==NSNotFound){
        NSLog(@" test2");
        if(counter==1)
        {
            changedUrl = [NSString stringWithFormat:@"%@.com",changedUrl];
            NSLog(@" %@", changedUrl);
        }
        else{
          counter=1; 
            changedUrl = [NSString stringWithFormat:@"%@.com",[aTextField text]];
        }
        
    }
    
    if(counter==1)
    {    [webView loadRequest:[NSURLRequest requestWithURL:
                          [NSURL URLWithString:changedUrl]]];
    }
    else {
        [webView loadRequest:[NSURLRequest requestWithURL:
                                                    [NSURL URLWithString:[aTextField text]]]];

    }
        
    
	return YES;
}

-(void)webViewDidStartLoad:(UIWebView *)aWebView
{
	[activityIndicator startAnimating];
	[stopButton setEnabled:YES];
	[refreshButton setEnabled:YES];
	if ([webView canGoBack]) {
		[backButton setEnabled:YES];
	} else {
		[backButton setEnabled:NO];
	}
	if ([webView canGoForward]) {
		[forwardButton setEnabled:YES];
	} else {
		[forwardButton setEnabled:NO];
	}
}

-(void)webViewDidFinishLoad:(UIWebView *)aWebView
{
	[activityIndicator stopAnimating];
	[stopButton setEnabled:NO];
	[refreshButton setEnabled:YES];
	if ([webView canGoBack]) {
		[backButton setEnabled:YES];
	} else {
		[backButton setEnabled:NO];
	}
	if ([webView canGoForward]) {
		[forwardButton setEnabled:YES];
	} else {
		[forwardButton setEnabled:NO];
	}
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
