//
//  YourSafariAppDelegate.h
//  YourSafari
//
//  Created by SE420701 on 10/25/10.
//  Copyright 2010 Tulsa Community College. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YourSafariViewController;

@interface YourSafariAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    YourSafariViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet YourSafariViewController *viewController;

@end

