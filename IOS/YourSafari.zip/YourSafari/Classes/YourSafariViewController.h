//
//  YourSafariViewController.h
//  YourSafari
//
//  Created by SE420701 on 10/25/10.
//  Copyright 2010 Tulsa Community College. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YourSafariViewController : UIViewController {
	IBOutlet UITextField *address;
	IBOutlet UIWebView* webView;
	IBOutlet UIBarButtonItem* refreshButton;
	IBOutlet UIBarButtonItem* forwardButton;
	IBOutlet UIBarButtonItem* backButton;
	IBOutlet UIBarButtonItem* stopButton;
	
	UIActivityIndicatorView* activityIndicator;

}

-(IBAction)refresh:(id)sender;
-(IBAction)forward:(id)sender;
-(IBAction)back:(id)sender;
-(IBAction)stop:(id)sender;

@end

