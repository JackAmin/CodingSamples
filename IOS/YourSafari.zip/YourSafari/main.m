//
//  main.m
//  YourSafari
//
//  Created by SE420701 on 10/25/10.
//  Copyright 2010 Tulsa Community College. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
