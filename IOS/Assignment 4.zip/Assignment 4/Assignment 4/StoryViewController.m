//
//  StoryViewController.m
//  Assignment 4
//
//  Created by Amin Sharif on 12-10-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "StoryViewController.h"

@interface StoryViewController ()

@end

@implementation StoryViewController
@synthesize donePressed;

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    [doneButton setHidden:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    
        
        if (![[textField text] isEqualToString:@""]){
            NSUInteger rangeLocation=[[textViewOne text] rangeOfString:[textField text]].location;
            //NSRange range=NSMakeRange(rangeLocation, 0);
            NSRange range=NSMakeRange(rangeLocation, [textField text].length);
            
            if (range.location!=NSNotFound){
                [textViewOne becomeFirstResponder];
                [textViewOne setSelectedRange:range];
            }
        }
        return NO;

}

-(BOOL)textView:(UITextView *)textView
shouldChangeTextInRange:(NSRange)range
replacementText:(NSString *)text{


    NSLog(@"in here");
        if([text intValue] !=0 || [text isEqualToString:@"0"]){
            return NO;
        }
        
        return YES;
    
}


- (void)viewDidLoad
{
    NSLog(@"not here");
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    textViewOne = nil;
    searchFieldOne = nil;
    doneButton = nil;
    [self setDonePressed:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}


- (IBAction)donePressed:(id)sender {
    [doneButton setHidden:YES];
    [textViewOne resignFirstResponder];
}
@end
