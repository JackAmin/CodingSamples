//
//  Second.h
//  Assignment 4
//
//  Created by Amin Sharif on 12-10-12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Second : UIViewController<UITextFieldDelegate, UITextViewDelegate>
{
    
     IBOutlet UIButton *doneButton;
     IBOutlet UITextField *searchFieldNun;
     IBOutlet UITextView *textViewNum;
}
@property (weak, nonatomic) IBOutlet UIButton *donePressed;
- (IBAction)donePressed:(id)sender;

@end
