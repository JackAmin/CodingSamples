//
//  SimpleTextViewController.h
//  SimpleText
//
//  Created by SE420701 on 9/10/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleTextViewController : UIViewController < UITextFieldDelegate,UITextViewDelegate>
{
    IBOutlet UITextView *textViewOne;
    IBOutlet UITextView *textViewNum;
    IBOutlet UITextField *searchFieldNun;
    IBOutlet UITextField *searchFieldOne;
    IBOutlet UIButton *doneButton;
}

-(IBAction)donePressed:(id)sender;

@end
