//
//  SimpleTextAppDelegate.h
//  SimpleText
//
//  Created by SE420701 on 9/10/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SimpleTextViewController;

@interface SimpleTextAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) SimpleTextViewController *viewController;

@end
