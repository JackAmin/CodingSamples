//
//  SimpleTextViewController.m
//  SimpleText
//
//  Created by SE420701 on 9/10/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import "SimpleTextViewController.h"

@interface SimpleTextViewController ()

@end

@implementation SimpleTextViewController

-(BOOL)textViewShouldBeginEditing:(UITextView *)textView{
    [doneButton setHidden:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    if( textField == searchFieldNun)
    {
        if (![[textField text] isEqualToString:@""]){
            NSUInteger rangeLocation=[[textViewNum text] rangeOfString:[textField text]].location;
            //NSRange range=NSMakeRange(rangeLocation, 0);
            NSRange range=NSMakeRange(rangeLocation, [textField text].length);
            
            if (range.location!=NSNotFound){
                [textViewNum becomeFirstResponder];
                [textViewNum setSelectedRange:range];
            }
        }
        return NO;
    

    }
    else {
        
       if (![[textField text] isEqualToString:@""]){
           NSUInteger rangeLocation=[[textViewOne text] rangeOfString:[textField text]].location;
           //NSRange range=NSMakeRange(rangeLocation, 0);
           NSRange range=NSMakeRange(rangeLocation, [textField text].length);

           if (range.location!=NSNotFound){
               [textViewOne becomeFirstResponder];
               [textViewOne setSelectedRange:range];
           }
       }
        return NO;
    }
}

-(BOOL)textView:(UITextView *)textView
shouldChangeTextInRange:(NSRange)range
replacementText:(NSString *)text{
    if(textView == textViewNum)
    {
        if([text intValue] !=0 || [text isEqualToString:@"0"]||
           [text isEqualToString:@""]){
            return YES;
        }
        
        return NO;
        
    }
    else {
    
        if([text intValue] !=0 || [text isEqualToString:@"0"]){
            return NO;
        }
    
        return YES;
    }
}

-(IBAction)donePressed:(id)sender{
    [doneButton setHidden:YES];
    [textViewOne resignFirstResponder];
    [textViewNum resignFirstResponder];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
