//
//  TouchDrawView.h
//  TouchTracker
//


#import <UIKit/UIKit.h>


@interface TouchDrawView : UIView {
	NSMutableDictionary *linesInProcess;
	NSMutableArray *completeLines;
    int count;
} 
- (void)endTouches:(NSSet *)touches; 

@end
