//
//  TouchTrackerAppDelegate.h
//  TouchTracker
//


#import <UIKit/UIKit.h>

@interface TouchTrackerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

