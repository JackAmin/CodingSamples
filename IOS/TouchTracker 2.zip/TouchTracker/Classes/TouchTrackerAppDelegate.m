//
//  TouchTrackerAppDelegate.m
//  TouchTracker
//


#import "TouchTrackerAppDelegate.h"

@implementation TouchTrackerAppDelegate

@synthesize window;

- (BOOL)application:(UIApplication *)application 
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch
    [window makeKeyAndVisible];
	return YES;
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
