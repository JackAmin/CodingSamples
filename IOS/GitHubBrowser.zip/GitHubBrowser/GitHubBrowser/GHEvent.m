//
//  GHEvent.m
//  GitHubBrowser
//
//  Created by SE420701 on 10/29/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import "GHEvent.h"

@implementation GHEvent

@synthesize repoName=_repoName;
@synthesize repoURL=_repoURL;
@synthesize userName=_userName;

-(id)initWithNSDictionary:(NSDictionary *)dictFromJSON
{
    self=[super init];
    if (self)
    {
        id repoObj=[dictFromJSON objectForKey:@"repo"];
        if (([repoObj isKindOfClass:[NSDictionary class]])) {
            _repoName=[repoObj objectForKey:@"name"];
            _repoURL=[repoObj objectForKey:@"url"];
        }
        
        id actorObj=[dictFromJSON objectForKey:@"actor"];
        if ([actorObj isKindOfClass:[NSDictionary class]]) {
            _userName=[actorObj objectForKey:@"login"];
        }
    }
    
    return self;
}

-(id) init{
    return [self initWithNSDictionary:nil];
}

-(NSString *) description
{
    return [NSString stringWithFormat:@"Repo=%@ User=%@", self.repoName, self.userName];
}

+(NSArray *)eventsFromJSON:(NSData *)jsonData
{
    NSError *parseError;
    
    id parsedObj=[NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&parseError];
    
    if(!parsedObj){
        NSLog(@"Error parsing JSON: %@", parseError);
        return nil;
    }
    
    if ([parsedObj isKindOfClass:[NSArray class]]) {
        NSArray *parsedEvents=(NSArray *)parsedObj;
        NSMutableArray *ghEvents=[[NSMutableArray alloc] initWithCapacity:[parsedEvents count]];
        
        for (id event in parsedEvents) {
            if ([event isKindOfClass:[NSDictionary class]]) {
                GHEvent *newEvent=[[GHEvent alloc] initWithNSDictionary:event];
                [ghEvents addObject:newEvent];
            }
        }
        return ghEvents;
    }
    return nil;
}







@end
