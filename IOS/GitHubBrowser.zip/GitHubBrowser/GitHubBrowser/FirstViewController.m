//
//  FirstViewController.m
//  GitHubBrowser
//
//  Created by SE420701 on 10/29/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import "FirstViewController.h"
#import "GHEvent.h"

@interface FirstViewController ()

@property (nonatomic, strong) NSArray *ghEvents;
@property (nonatomic, strong) UILabel *statusLabel;
//-(void)refreshEvents;
-(void)refreshEventsAndRun:(dispatch_block_t)handler;

@end

@implementation FirstViewController

@synthesize ghEvents=_ghEvents;
@synthesize eventTable=_eventTable;
@synthesize statusLabel=_statusLabel;


-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y<=-40.0){
        self.statusLabel.text=@"Found Me!";
    }
    if (scrollView.contentOffset.y==0.0){
        self.statusLabel.text=@"peek-a-boo!";
    }
}


-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    const float max_offset=40.0f;
    if (scrollView.contentOffset.y<=-max_offset){
       // [self refreshEvents];
        
        
        void (^animate)(float top)=^(float top){
            [UIView beginAnimations:nil context:NULL];
            [UIView setAnimationDuration:0.2];
            scrollView.contentInset=UIEdgeInsetsMake(top, 0.0f, 0.0f, 0.0f);
            [UIView commitAnimations];
        };
        
        animate(40.0f);
       // dispatch_after(dispatch_time(DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue(),
       //                ^(){animate(0.0f);});
        [self refreshEventsAndRun:^(){animate(0.0);}];
        
    }
    
}

-(void)refreshEventsAndRun:(dispatch_block_t)finishRefreshHandler{
    
    NSString *ghEventsAPIURL=@"https://api.github.com/events";
    NSURL *url=[[NSURL alloc] initWithString:ghEventsAPIURL];
    NSURLRequest *newReq=[[NSURLRequest alloc] initWithURL:url];
    
    void (^handler)(NSURLResponse *urlResponse, NSData *responseData, NSError *error)=
            ^(NSURLResponse *urlResponse, NSData *responseData, NSError *error)
    {
        self.ghEvents=[GHEvent eventsFromJSON:responseData];
        [self.eventTable reloadData];
        finishRefreshHandler();
    };
    
    [NSURLConnection sendAsynchronousRequest:newReq
                                       queue:[NSOperationQueue mainQueue]
                           completionHandler:handler];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self refreshEventsAndRun:^(){}];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Events";
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
        NSString *jsonPath=[[NSBundle mainBundle] pathForResource:@"gh_events" ofType:@"json"];
        NSData *jsonData=[NSData dataWithContentsOfFile:jsonPath];
        self.ghEvents=[GHEvent eventsFromJSON:jsonData];
        
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.eventTable setDelegate:self];
    
    CGRect labelRect=self.eventTable.bounds;
    labelRect.origin.y-=30.0f;
    labelRect.size.height=20.0f;
    self.statusLabel=[[UILabel alloc] initWithFrame:labelRect];
    [self.statusLabel setAutoresizingMask:UIViewAutoresizingFlexibleWidth];
    [self.statusLabel setFont:[UIFont boldSystemFontOfSize:24]];
    [self.statusLabel setTextAlignment:UITextAlignmentCenter];
    [self.statusLabel setText:@"Peek-a-boo!"];
    [self.eventTable addSubview:self.statusLabel];
    [self refreshEventsAndRun:^(){}];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.ghEvents count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"MyCell";
    
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell==nil){
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    cell.textLabel.text=[[self.ghEvents objectAtIndex:[indexPath row]] description];
    
    return cell;
    
}











@end
