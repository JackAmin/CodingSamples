//
//  GHEvent.h
//  GitHubBrowser
//
//  Created by SE420701 on 10/29/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GHEvent : NSObject

    @property (nonatomic, copy) NSString *repoName;
    @property (nonatomic, copy) NSString *repoURL;
    @property (nonatomic, copy) NSString *userName;

-(id)initWithNSDictionary:(NSDictionary *)dictFromJSON;

+(NSArray *)eventsFromJSON:(NSData *) jsonData;


@end
