//
//  FirstViewController.h
//  GitHubBrowser
//
//  Created by SE420701 on 10/29/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController <UITableViewDataSource, UIScrollViewDelegate>

@property (nonatomic, weak) IBOutlet UITableView *eventTable;

@end
