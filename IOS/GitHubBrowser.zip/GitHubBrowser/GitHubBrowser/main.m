//
//  main.m
//  GitHubBrowser
//
//  Created by SE420701 on 10/29/12.
//  Copyright (c) 2012 SE420701. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
