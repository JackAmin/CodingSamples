//
//  RolesTVC.m
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RolesTVC.h"

@interface RolesTVC ()

@end

@implementation RolesTVC
@synthesize  selectedRole;
@synthesize fetchedResultsController =_fetchedResultsController;
@synthesize managedObjectContext =_managedObjectContext;


-(void)setupFetchedResultsController
{
    //1 - Decide what Entity we want
    NSString *entityName=@"Role";
    //2 - Request that Entity
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:entityName];
    //3 - filter if needed
    //request.predicate = [NSPredicate predicateWithFormat:@"Role.name=blah"];
    
    //4 - Sort it if needed
    request.sortDescriptors=[NSArray arrayWithObject:[NSSortDescriptor 
                                                      sortDescriptorWithKey:@"name" 
                                                      ascending:YES 
                                                      selector:@selector(localizedCaseInsensitiveCompare:)]];
    //5 - Fetch it
    self.fetchedResultsController= [[NSFetchedResultsController alloc] 
                                    initWithFetchRequest:request
                                    managedObjectContext:self.managedObjectContext
                                    sectionNameKeyPath:nil
                                     cacheName:nil];
    [self performFetch];
                                    
                            
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupFetchedResultsController];
    
}

#pragma mark - Table view data source




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Roles Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell==nil)
    {
        cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier: CellIdentifier];
    }
    // Configure the cell...
    Role *role=[self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.textLabel.text=role.name;
    
    return cell;
}
-(void) theSaveButtonOnTheAddRoleTVCWasTapped:(AddRoleTVC *)controller
{
    [controller.navigationController popViewControllerAnimated:YES];
}
-(void) theSaveButtonOnTheRoleDetialTVCWasTapped:(RoleDetialTVC *)controller
{
    [controller.navigationController popViewControllerAnimated:YES];
}
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString: @"Add Role Segue"])
    {
        NSLog(@"Setting RolesTVC as a delegate of AddRolesTVC");
        AddRoleTVC *addRoleTVC = segue.destinationViewController;
        addRoleTVC.delegate =self;
        addRoleTVC.managedObjectContext=self.managedObjectContext;
    }
    else {
        RoleDetialTVC* roleDetailTVC=segue.destinationViewController;
        roleDetailTVC.delegate=self;
        roleDetailTVC.managedObjectContext=self.managedObjectContext;
        
        NSIndexPath *indexPath=[self.tableView indexPathForSelectedRow];
        self.selectedRole =[self.fetchedResultsController objectAtIndexPath:indexPath];
        roleDetailTVC.role = self.selectedRole;
        
    }
}

-(void) tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [self.tableView beginUpdates];
        Role *roleToDelete= [self.fetchedResultsController objectAtIndexPath:indexPath];
        [self.managedObjectContext deleteObject:roleToDelete];
        [self.managedObjectContext save:nil];
        [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self performFetch];//refresh
        [self.tableView endUpdates];
        
    }
}
@end
