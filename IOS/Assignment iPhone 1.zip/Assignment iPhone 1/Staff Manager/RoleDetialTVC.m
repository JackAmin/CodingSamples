//
//  RoleDetialTVC.m
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RoleDetialTVC.h"

@interface RoleDetialTVC ()

@end

@implementation RoleDetialTVC

@synthesize roleNameTextField;
@synthesize roleDescribeTextField;
@synthesize permanentSegControl;
@synthesize delegate;
@synthesize managedObjectContext =_managedObjectContext;
@synthesize role=_role;
-(void)viewDidLoad
{
    self.roleNameTextField.text=self.role.name;
    self.roleDescribeTextField.text =self.role.describe;
    /*if(self.role.permanent)
    {
        self.permanentSegControl.selectedSegmentIndex=1;
    }
    else {
        self.permanentSegControl.selectedSegmentIndex=0;
    }*/
    self.navigationItem.title = self.role.name;
    [super viewDidLoad];
}
-(void)viewDidUnload
{
    [self setRoleNameTextField:nil];
    [self setRoleDescribeTextField:nil];
    [self setPermanentSegControl:nil];
    [super viewDidUnload];
}

-(IBAction)save:(id)sender
{
    NSLog(@"Save was Tapped on RoleDetialTVC");
    
    [self.role setName:roleNameTextField.text];
    [self.role setDescribe:roleDescribeTextField.text];
    /*if(permanentSegControl.selectedSegmentIndex)
    {
        
    }
    else {
       [self.role setPermanent:false];
    } */
    
    [self.managedObjectContext save:nil];

    [self.delegate theSaveButtonOnTheRoleDetialTVCWasTapped:self];
}
@end
