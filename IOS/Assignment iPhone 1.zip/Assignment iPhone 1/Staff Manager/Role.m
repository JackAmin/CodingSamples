//
//  Role.m
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Role.h"


@implementation Role

@dynamic name;
@dynamic describe;
@dynamic permanent;

@end
