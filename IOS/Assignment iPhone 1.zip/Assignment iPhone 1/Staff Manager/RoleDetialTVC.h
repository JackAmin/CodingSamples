//
//  RoleDetialTVC.h
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Role.h"

@class RoleDetialTVC;
@protocol RoleDetialTVCDelegate
-(void) theSaveButtonOnTheRoleDetialTVCWasTapped:(RoleDetialTVC *) controller; //parent to child link
@end

@interface RoleDetialTVC : UITableViewController
@property (strong, nonatomic) IBOutlet UITextField *roleNameTextField;
@property (strong, nonatomic) IBOutlet UITextField *roleDescribeTextField;
@property (strong, nonatomic) IBOutlet UISegmentedControl *permanentSegControl;
@property (nonatomic, weak) id <RoleDetialTVCDelegate> delegate; //link to parent
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) Role *role;
-(IBAction)save:(id)sender;
@end
