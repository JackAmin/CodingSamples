//
//  StoryViewController.h
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoryViewController : UIViewController

@end
