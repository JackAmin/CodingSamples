//
//  Role.h
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Role : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * describe;
@property (nonatomic) Boolean * permanent;



@end
