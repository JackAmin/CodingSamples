//
//  AddRoleTVC.m
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AddRoleTVC.h"

@interface AddRoleTVC ()

@end

@implementation AddRoleTVC

@synthesize roleNameTextField;
@synthesize roleDescribeTextField;
@synthesize permanentSegControl;
@synthesize delegate;
@synthesize managedObjectContext =_managedObjectContext;

-(void)viewDidUnload
{
    [self setRoleNameTextField:nil];
    [self setRoleDescribeTextField:nil];
    [self setPermanentSegControl:nil];
    [super viewDidUnload];
}

-(IBAction)save:(id)sender
{
    NSLog(@"Save was Tapped on ADDROLeTVC");
    
    Role *role = [NSEntityDescription insertNewObjectForEntityForName:@"Role" 
                                               inManagedObjectContext:self.managedObjectContext];
    role.name =roleNameTextField.text;
    role.describe = roleDescribeTextField.text;
    /*if(permanentSegControl.selectedSegmentIndex)
    {
      role.permanent = true;  
    }
    else {
        role.permanent =false;
    }
    */
    [self.managedObjectContext save:nil];
    
    [self.delegate theSaveButtonOnTheAddRoleTVCWasTapped:self];
}
@end
