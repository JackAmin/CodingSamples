//
//  RolesTVC.h
//  Staff Manager
//
//  Created by Amin Sharif on 12-10-22.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AddRoleTVC.h"
#import "CoreDataTableViewController.h"
#import "Role.h"
#import "RoleDetialTVC.h"

@interface RolesTVC : CoreDataTableViewController <AddRoleTVCDelegate, RoleDetialTVCDelegate>

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) Role* selectedRole;

@end
