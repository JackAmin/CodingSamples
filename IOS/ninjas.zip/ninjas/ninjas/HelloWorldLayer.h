//
//  HelloWorldLayer.h
//  ninjas
//
//  Created by SE420705 on 11/19/12.
//  Copyright __MyCompanyName__ 2012. All rights reserved.
/**/


#import <GameKit/GameKit.h>

// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayerColor <GKAchievementViewControllerDelegate, GKLeaderboardViewControllerDelegate>
{
    NSMutableArray *_targets;
    NSMutableArray *_projectiles;
    CCLabelTTF *_gameScore;
    CCLabelTTF *_Score;
    CCLabelTTF *_hitPoints;
    CCLabelTTF *_Points;
    int _projectilesDestroyed;
    int scoreCount;
    int hitCount;
    
}
@property (nonatomic, retain) CCLabelTTF *gameScore;
@property (nonatomic, retain) CCLabelTTF *Score;
@property (nonatomic, retain) CCLabelTTF *hitPoints;
@property (nonatomic, retain) CCLabelTTF *Points;
// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end
