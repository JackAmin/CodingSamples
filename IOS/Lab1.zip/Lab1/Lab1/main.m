//
//  main.m
//  Lab1
//
//  Created by Amin Sharif on 12-08-28.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Lab1AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Lab1AppDelegate class]));
    }
}
