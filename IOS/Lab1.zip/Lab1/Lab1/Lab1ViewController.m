//
//  Lab1ViewController.m
//  Lab1
//
//  Created by Amin Sharif on 12-08-28.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Lab1ViewController.h"

@interface Lab1ViewController ()

@end

@implementation Lab1ViewController



-(IBAction)changeColor:(id)sender{
    UISegmentedControl *seg = (UISegmentedControl *) sender;
    switch ([seg selectedSegmentIndex]) {
        case 0:
            [textField setTextColor:[UIColor redColor]];
            break;
        case 1:
            [textField setTextColor:[UIColor greenColor]];
            break;
        case 2:
            [textField setTextColor:[UIColor blueColor]];
            break;
        case 3:
            [textField setTextColor:[UIColor blackColor]];
            break;
            
    }
    
}

-(IBAction)changeTrans:(id)sender{
    [textField setAlpha:[(UISlider *)sender value]];
}

-(IBAction)toggleText:(id)sender{
    [textField setHidden:![textField isHidden]];
}

-(IBAction)changeText:(id)sender{
    if([[textField text]isEqualToString:@"Hello World!"]){
       
        [textField setText:@"World, Hello!"];
    }
    else {
        [textField setText:@"Hello World!"];

    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
