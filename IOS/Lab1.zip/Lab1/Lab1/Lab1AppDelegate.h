//
//  Lab1AppDelegate.h
//  Lab1
//
//  Created by Amin Sharif on 12-08-28.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Lab1ViewController;

@interface Lab1AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Lab1ViewController *viewController;

@end
