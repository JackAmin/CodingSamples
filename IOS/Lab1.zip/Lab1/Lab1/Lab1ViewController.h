//
//  Lab1ViewController.h
//  Lab1
//
//  Created by Amin Sharif on 12-08-28.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Lab1ViewController : UIViewController
{

    IBOutlet UILabel *textField;
    IBOutlet UISlider *slider;
    IBOutlet UISegmentedControl *seg;
    IBOutlet UISwitch *onOff;
    IBOutlet UIButton *button;
}
-(IBAction)changeColor:(id)sender;
-(IBAction)changeTrans:(id)sender;
-(IBAction)toggleText:(id)sender;
-(IBAction)changeText:(id)sender;

@end
