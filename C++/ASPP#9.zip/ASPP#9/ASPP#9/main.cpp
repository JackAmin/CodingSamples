//
//  main.cpp
//  ASPP#9
//
//  Created by Amin Sharif on 12-11-09.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

int main(int argc, const char * argv[])
{
    //declaring vars
    ifstream inStream;
    string boyNames[1000];
    string girlNames[1000];
    string selectedName;
    int foundBoy=0;;
    int foundGirl=0;
    
    //I was unable to make this work without the direct path of the file. When you run this file, please change this to the directpath on your computer.
    inStream.open("/Users/JackAmin/CreatingApps/Class/C++/ASPP#9/ASPP#9/boynames.txt");
    
    //fills up boyNames array from the file boynames.txt
    for(int i=0;i<1000;i++)
    {
        getline(inStream,boyNames[i]);
        
    }
    
    inStream.close();
    
      //I was unable to make this work without the direct path of the file. When you run this file, please change this to the directpath on your computer.
    inStream.open("/Users/JackAmin/CreatingApps/Class/C++/ASPP#9/ASPP#9/girlnames.txt");
    
    //fills up girlNames array from the file girlnames.txt
    for(int i=0;i<1000;i++)
    {
        getline(inStream,girlNames[i]);
    }
    inStream.close();
    
    
    //gets a name from the user
    cout<<"please enter a name: "<<endl;
    cin>>selectedName;
    
    //searches the boynames array for selected name. If found foundboy=1.
    for (int i=0;i<1000;i++) {
        if(boyNames[i].substr(0,selectedName.length()) == selectedName)
        {
            cout<<selectedName<<" is ranked "
                <<i+1
                <<" in popularity among boys with "
                <<boyNames[i].substr(selectedName.length()+1,boyNames[i].length())
                <<" namings "
                <<endl;
            foundBoy=1;
            //ends forloop
            i=1001;
        }
    }
    
    //if the boy wasn't found in the array then this message is outputed.
    if(foundBoy==0)
        cout<<selectedName<<" is not ranked among the top 1000 boy names"<<endl;
   
    //searches the girlnames array for selected name. If found foundgirl=1.
    for (int i=0;i<1000;i++) {
        if(girlNames[i].substr(0,selectedName.length()) == selectedName)
        {
            cout<<selectedName<<" is ranked "
            <<i+1
            <<" in popularity among girls with "
            <<girlNames[i].substr(selectedName.length()+1,girlNames[i].length())
            <<" namings";
            foundGirl=1;
            //ends forloop
            i=1001;
        }
    }
    //if the girl wasn't found in the array then this message is outputed.
    if(foundGirl==0)
        cout<<selectedName<<" is not ranked among the top 1000 girl names"<<endl;
    return 0;
}

