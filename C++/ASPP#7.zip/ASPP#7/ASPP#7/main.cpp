//
//  main.cpp
//  ASPP#7
//
//  Created by Amin Sharif on 12-11-09.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include <string>

using namespace std;

int main(int argc, const char * argv[])
{
    string line;
    
    //since the program counts the beginning of a line as a word. numOfWords is set to 1 to beggin with.
    int numOfWords=1;
    
    // an array that will hold number of letters. The first index corraspands  to a, second index to b.... and the last index to z.
    int alpha[26];
    
    //asking user to enter line of text and storing it in the var line.
    cout << "Please enter a line of text and press enter.\n";
    getline(cin,line);
    
    //to keep the code more readable
    char holder;
    
    //lowercase all the lettters in the string, line.
    transform(line.begin(),line.end(), line.begin(),::tolower);
    
    
    //setting all values of alpha to 0.
    for(int i=0; i<26;i++)
    {
        alpha[i]=0; 
    }
    
    for(int i =0; i <line.length();i++)
    {
       // if a space, period, comma, or a new line appears in the string line then numOfWords is incremented by 1.
        if((line.substr(i,1)==" ")
           ||(line.substr(i,1)==".")
           ||(line.substr(i,1)==",")
           ||(line.substr(i,1)=="\n"))
        {
            numOfWords++;
        }
        
        else{
            //change the first index string into a char and place into holder. This is done to make the process less confusing.
            holder=static_cast<char>(line[i]);
            
            //97 is the ascii number for 'a'. We cast the char 'a' letter into an int which will be between  97-123(a-z). We then subtract 97 from this number which will give us a number between 0-25, which is exactly how big our array,alpha is. We finnally add 1 to whatever number is in that index, increasing the number of occurances of that letter.
            alpha[static_cast<int>(holder)-97]+=1;
        }
        
    }
    
    //printing result
    cout<<numOfWords<<" words \n";
    for(int i=0; i<26;i++)
    {
        if(alpha[i]!=0)
        {
            //converting the index back into a char.
            cout<<alpha[i]<<" "<<static_cast<char>(i+97)<<endl;
        }
    }
    return 0;
}

