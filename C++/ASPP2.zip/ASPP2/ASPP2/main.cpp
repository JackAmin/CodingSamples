//
//  main.cpp
//  ASPP2
//
//  Created by Amin Sharif on 12-09-13.
// 
//

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
 
    //if repeat =1 then the program will repeat,
    //if repeat = 0 then the program will end.
    int repeat =1;
    
    while(!repeat ==0)
    {
        //storing each winner inside a varable. Then making sure they don't win again.
        int num1=0;
        int num2=0;
        int num3=0;
        int num4=0;
        
        //selected to win a prize
        int selected =-1;
        
        while (selected!=0)
        {
            //draws a number from 1 to 25
            selected =(rand()%25 +1);
            
            //sets the first seclected winner to num1.
            //Checks to see if winner is already selected, if so then moves onto another selection. Storing each unique winner into num2,num3,num4.
            if(num1==0)
            {
                num1=selected;
            }
            if(num2==0 && selected!=num1&& selected!=num3 && selected!=num4)
            {
                num2=selected;
            }
            if(num3==0&& selected!=num1&& selected!=num2 && selected!=num4)
            {
                num3=selected;
            }
            if(num4==0&& selected!=num1&& selected!=num2 && selected!=num3)
            {
                num4=selected;
            }
        
            //if all the winners are chosen, then set selected to 0 and leave the loop
            if(num1!=0&& num2!=0&& num3!=0 && num4!=0)
            {
                selected =0;
            }
        
            
        }
        
        cout<< "Your winners are "
            <<num1
            <<", "
            <<num2
            <<", "
            <<num3
            <<", "
            <<num4;
        
        cout<<"\n \n To run program again press 1, otherwise press 0 to end the program ";
        //expects the user to press 1 or 0. the program will repeat if any integer other than 0 is pressed, however since this was not part of the program, I didn't put any checks to handle errors.
        cin>>repeat;
        cout<<endl;
        
    }
    

    return 0;
}

