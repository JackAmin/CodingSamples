//
//  main.cpp
//  ASPP1
//
//  Created by Amin Sharif on 12-09-13.
//  
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[])
{
    // Number excercises
    int N=0;
    //repeat program var. 
    //if repeat =1 then the program will repeat,
    //if repeat = 0 then the program will end.
    int repeat =1;
    //score recived for excersise
    double score=0.0;
    //total points possible for excersise
    double total=0.0;
    // sum of the scores
    double sumScore=0.0;
    // sum of total possible points
    double  sumTotal =0.0;
    
    //repeats if the user wants the use the program again
    while(!repeat ==0){
        cout << " How many exerises to input? ";
        cin>> N;
        //loops N times
        for(int i=0 ; i<N;i++)
        {
            cout<<" Score received for exercise "<< i+1<<": ";   
            cin>>score;
            cout<<" Total points possible for exercise "<< i+1<<": ";
            cin>>total;
            sumScore+=score;
            sumTotal+=total;
        }
            
            cout<<"\n Your total is "
                <<sumScore
                <<" out of "
                <<sumTotal
                <<", or ";
            //sets the precision after the decimal point to 2. Example 15.88.
            cout.setf(ios::fixed);
            cout.setf(ios::showpoint);
            cout.precision(2);
            cout<<(sumScore/sumTotal)*100<<"%."; 
            cout<<"\n \n To run program again press 1, otherwise press 0 to end the program ";
            //expects the user to press 1 or 0. the program will repeat if any integer other than 0 is pressed, however since this was not part of the program, I didn't put any checks to handle errors.
            cin>>repeat;
            cout<<endl;
    }
    return 0;
}

