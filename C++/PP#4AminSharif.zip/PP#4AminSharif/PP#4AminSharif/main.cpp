//
//  main.cpp
//  PP#4AminSharif
//
//  Created by Amin Sharif on 12-10-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
using namespace std;

int main(int argc, const char * argv[])
{
   // Write a program that reads in an array of type int . You may assume that there are fewer than 50 entries in the array. Your program determines how many entries are used. The output is to be a two- column list. The first column is a list of the distinct array elements; the second column is the count of the number of occur-rences of each element. The list should be sorted on entries in the first column, largest to smallest. For the array values – 12 3 – 12 4 1 1 – 12 1 – 1 1 2 3 4 2 3 – 12 the output should be N Count 4 2 3 3 2 2 1 4 – 1 1 – 12 4
    //delcaring 
    int arr[50];
    int input=-1;
    int counter=0;
    int num=0;
    int numCounter=0;
    int temp=0;
    //Setting all elements to zero
    for(int i=0; i<50;i++)
    {
        arr[i]=0;
    }

    cout<<"Please enter up to 50 numbers and enter 0 when you're finished \n";
    
    //loops until 50 integers are entered or 0 is pressed.
    while(input!=0&&counter<50)
    {
        cin>>input;
        if(input!=0)
        {
            arr[counter]=input;
            counter++;
        }

    }
    //sorts the array from greatest to lowest
    for(int i=0;i<counter;i++)
    {
        for(int j=i+1; j<counter;j++)
            if(arr[i]<arr[j])
            {
                temp=arr[i];
                arr[i]=arr[j];
                arr[j]=temp;
            }

    }
    //prints out the columns 
    cout<<"N     Count \n";
    for(int i=0; i<counter;i++)
    {
        if(arr[i]!=0)
        {
            num=arr[i];
            cout<<arr[i]<<"     ";
            //Counts number of occurances of the number.
            for(int j=i; j<counter;j++)
            {
            
                if(arr[j]==num)
                {
                    //keeps track of number of occurances
                    numCounter++;
                    //sets found duplicate values to 0 so that it is not printed more than once
                    arr[j]=0;
                }
            }
            cout<<numCounter<<endl;
            numCounter=0;
        }
    }
    
    return 0;
}

