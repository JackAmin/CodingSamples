//
//  main.cpp
//  PP#6AminSharif
//
//  Created by Amin Sharif on 12-10-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
#include <cmath>
using namespace std;
//Define a class for complex numbers. A complex number is a number of the form a + b* i where for our purposes, a and b are numbers of type double , and i is a number that represents the quantity sqrt( - 1) . Represent a complex number as two values of type double . Name the member variables real and imaginary . ( The vari-able for the number that is multiplied by i is the one called imaginary .) Call the class Complex . Include a constructor with two parameters of type double that can be used to set the member variables of an object to any values. Include a constructor that has only a single parameter of type double ; call this parameter realPart and define the constructor so that the object will be initialized to realPart + 0* i . Include a default constructor that initializes an object to 0 ( that is, to 0 + 0* i ). Overload all the following operators so that they correctly apply to the type Complex : == , + , - , * , >> , and << . You should also write a test program to test your class. Hints: To add or subtract two complex numbers, add or subtract the two member variables of type double . The product of two complex numbers is given by the following formula: (a + b*i)*(c+d*i)==(a*c - b*d)+(a*d +b*c)i.

class Complex
{
    public:
        Complex();
        Complex(double realPart);
        Complex(double realIn, double imaginaryIn);
        friend bool operator ==(const Complex& first, const Complex& second);
        friend const Complex operator +(const Complex& first, const Complex& second);
        friend const Complex operator -(const Complex& first, const Complex& second);
        friend const Complex operator *(const Complex& first, const Complex& second);
        friend ostream& operator <<(ostream& outputStream, const Complex& first);
        friend istream& operator >>(istream& inputStream, Complex& first);

    private:
        double real;//a
        double imaginary;//number multiplied by i
};


Complex::Complex()
{
    real=0;
    imaginary=0;
}
Complex::Complex(double realPart)
{
    real = realPart;
    imaginary=0;
}
Complex::Complex(double realIn, double imaginaryIn)
{
    real=realIn;
    imaginary=imaginaryIn;
}

//if first ==secon then return true, otherwise return false
bool operator ==(const Complex& first, const Complex& second)
{
    if((first.real== second.real) && (first.imaginary == second.imaginary))
        return true;
    else 
        return false;
}
//add two complex objects and return the sum of the objects
const Complex operator +(const Complex& first, const Complex& second)
{
    Complex temp;
    temp.real = first.real + second.real;
    temp.imaginary = first.imaginary + second.imaginary;
    return temp;
}
//subtract two complex objects and return the subtraction of the objects
const Complex operator -(const Complex& first, const Complex& second)
{
    Complex temp;
    temp.real = first.real - second.real;
    temp.imaginary = first.imaginary - second.imaginary;
    return temp;
}
//Multiplies two Complex objects and returns the product
const Complex operator *(const Complex& first, const Complex& second)
{
    //using the formula (a + b*i)*(c+d*i)==(a*c - b*d)+(a*d +b*c)i
    //(first.real + first.imaginary*i)*(second.real +second.imaginary*i)==
    //(first.real * second.real - first.imaginary * second.imaginary)+ (first.real*second.imaginary +first.imaginary*second.real)
    Complex temp;
    temp.real = (first.real * second.real) - (first.imaginary * second.imaginary);
    temp.imaginary = (first.real*second.imaginary +first.imaginary*second.real);
    return temp;
}
//prints out the Complex number like so a + b*i
ostream& operator <<(ostream& outputStream, const Complex& first)
{
    if(first.imaginary>0)
    {
        outputStream << first.real<<" + "<<first.imaginary<<"i";
    }
    else 
    {
        outputStream << first.real<<" - "<<abs(first.imaginary)<<"i";
    }
    return outputStream;
}

//takes the input and puts it into the Complex object
istream& operator >>(istream& inputStream,  Complex& first)
{
    inputStream >> first.real>>first.imaginary;
    return inputStream;
}

int main()
{
    //declaring and setting two complex numbers
    Complex (0,1);//i
    Complex first(10,10);
    Complex second(5,5);
    Complex third;
    
    //test one: Tests addition
    cout<<"Test one: "<<first+second<<endl;
    
    //test two: Tests subtraction
    cout<<"Test two: "<<first-second<<endl;
    
    //test three: Tests bool
    if(first==second)
    {    
        cout<<"Test three: "<<"true \n";
    }
    else {
        cout<<"Test three: "<<"false \n";
    }
    
    //test four: Tests multiplication
    cout<<"Test four: "<<first*second<<endl;
    
    //test five: Tests input and output
    cout<<"Please enter a real and imaginary value \n";
    cin>>third;
    cout<<"Test five: "<<third<<endl;
    return 0;
}

