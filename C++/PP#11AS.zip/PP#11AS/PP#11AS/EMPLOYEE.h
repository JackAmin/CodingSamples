//
//  EMPLOYEE.h
//  PP#11AS
//
//  Created by Amin Sharif on 12-12-06.
//  Copyright (c) 2012 Amin Sharif. All rights reserved.
//

#ifndef __PP_11AS__EMPLOYEE__
#define __PP_11AS__EMPLOYEE__

// This is the interface for the class Employee.
// This is primarily intended to be used as a base class to derive
// classes for different kinds of employees.
#include <iostream>
#include <string>
using std:: string;
namespace SavitchEmployees
{
    class Employee
    {
    public:
        Employee( );
        Employee( const string& theName, const string& theSsn);
        string getName( ) const;
        string getSsn( ) const;
        double getNetPay( ) const;
        void setName( const string& newName);
        void setSsn( const string& newSsn);
        void setNetPay( double newNetPay);
        void printCheck( ) const;
    private:
        string name;
        string ssn;
        double netPay;
    };
} // SavitchEmployees

#endif /* defined(__PP_11AS__EMPLOYEE__) */
