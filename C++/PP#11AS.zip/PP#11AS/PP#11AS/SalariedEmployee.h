//
//  SalariedEmployee.h
//  PP#11AS
//
//  Created by Amin Sharif on 12-12-06.
//  Copyright (c) 2012 Amin Sharif. All rights reserved.
//

#ifndef __PP_11AS__SalariedEmployee__
#define __PP_11AS__SalariedEmployee__

#include <iostream>
// This is the header file salariedemployee. h.
// This is the interface for the class SalariedEmployee.
#include <string>
#include "EMPLOYEE.h"
using std:: string;
namespace SavitchEmployees
{
    class SalariedEmployee : public Employee
    {
        public:
            SalariedEmployee();
            SalariedEmployee ( const string& theName, const string& theSsn,
                              double theWeeklySalary);
            double getSalary( ) const;
            void setSalary( double newSalary);
            void printCheck( );
        private:
            double salary;
        // weekly
    };
} // SavitchEmployees
#endif /* defined(__PP_11AS__SalariedEmployee__) */
