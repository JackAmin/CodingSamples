//
//  main.cpp
//  PP#11AS
//
//  Created by Amin Sharif on 12-12-06.
//  Copyright (c) 2012 Amin Sharif. All rights reserved.
//A member variable of type string that contains the administrator’s title, ( such as Director or Vice President). ¦ A member variable of type string that contains the company area of respon-sibility ( such as Production, Accounting, or Personnel). ¦ A member variable of type string that contains the name of this administra-tor’s immediate supervisor. ¦ A protected member variable of type double that holds the administrator’s annual salary. It is possible for you to use the existing salary member if you changed private in the base class to protected . ¦ A member function called setSupervisor , which changes the supervisor name. ¦ A member function for ¦ A member function called print , which  ¦ Finally, an overloading of the member function printCheck( ) with appropri-ate notations on the check.

#include <iostream>
#include "EMPLOYEE.h"
#include "SalariedEmployee.h"
using namespace std;
namespace SavitchEmployees
{
    class Administrator: public SalariedEmployee
    {
    private:
        string adminTitle;
        string compResponsibility;
        string adminSupervisor;
    protected:
        double adminAnnualSalary;
    public:
        void setSupervisor(string name);
        void AdminDat();
        void print();
        void printCheck();
    };
}
int main(int argc, const char * argv[])
{

    SavitchEmployees::Administrator apple;
    apple.AdminDat();
    apple.print();
    return 0;
}
//which changes the supervisor name
void SavitchEmployees::Administrator::setSupervisor(string name)
{
    adminSupervisor=name;
}
//reading in an administrator’s data from the keyboard. 
void SavitchEmployees::Administrator::AdminDat()
{
    string holder;
    cout<<"Please enter Admin name: "<<endl;
    getline(cin,holder);
    setName(holder);
    cout<<"Please enter Admin title: "<<endl;
    getline(cin,adminTitle);
    cout<<"Please enter Admin's Responsibility: "<<endl;
    getline(cin,compResponsibility);
    cout<<"Please enter Admin's Supervisor: "<<endl;
    getline(cin,holder);
    setSupervisor(holder);
    cout<<"Please enter Admin's Annual Salary: "<<endl;
    cin>>adminAnnualSalary;
}
//outputs the object’s data to the screen.
void SavitchEmployees::Administrator::print()
{
    cout<<"Administrator name: "<<getName()<<endl;
    cout<<"Administrator title: "<<adminTitle<<endl;
    cout<<"Company Responsibility: "<<compResponsibility<<endl;
    cout<<"Administrator Supervisor"<<adminSupervisor<<endl;
    cout<<"Admin check"<<endl;
    printCheck();
}
//prints check
void SavitchEmployees::Administrator::printCheck()
{
    cout << "\n__________________________________________\n";
    cout << " Pay to the order of " << adminAnnualSalary << endl;
    cout << " The sum of " << adminAnnualSalary << " Dollars \n";
    cout << "__________________________________________\n";
    cout << " Check Stub: NOT NEGOTIABLE\n";
    cout << "__________________________________________\n";
}