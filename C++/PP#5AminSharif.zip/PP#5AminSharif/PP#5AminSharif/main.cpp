//
//  main.cpp
//  PP#5AminSharif
//
//  Created by Amin Sharif on 12-10-11.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
using namespace std;

class Odometer
{
    public:
    void reset();
    void setEfficiency(int newEff);
    void addMilesDriven(int newMD);
    double getConsumedGas();
    
    private:
    double milesDriven;//miles
    double efficiency;//miles per gallon

};
void Odometer::reset()
{
    milesDriven=0;
    efficiency=0;
}
void Odometer::setEfficiency(int newEff)
{
    efficiency=newEff;
}
void Odometer::addMilesDriven(int newMD)
{
    milesDriven+=newMD;
}
double Odometer::getConsumedGas()
{
    //returns the gas consumed since the last Odometer reset
    return milesDriven/efficiency;
}
int main()
{
    cout.setf(ios::fixed);
    cout.setf(ios::showpoint);
    cout.precision(2);
    //test one
    Odometer testOne;
    testOne.setEfficiency(45);
    testOne.addMilesDriven(45);
    cout<<"First Test, the gas consumed since last reset is : "<<testOne.getConsumedGas()<<" Gallons\n";
    //test two
    Odometer testTwo;
    testTwo.setEfficiency(5);
    testTwo.addMilesDriven(45);
    cout<<"Second Test, the gas consumed since last reset is : "<<testTwo.getConsumedGas()<<" Gallons\n";
    testTwo.reset();
    
    //test three
    Odometer testThree;
    testThree.reset();
    testThree.setEfficiency(30);
    testThree.addMilesDriven(4);
    cout<<"Third Test, the gas consumed since last reset is : "<<testThree.getConsumedGas()<<" Gallons\n";
    //test four
    Odometer testFour;
    testFour.setEfficiency(1);
    testFour.reset();
    testFour.setEfficiency(5);
    testFour.addMilesDriven(5);
    cout<<"Four Test, the gas consumed since last reset is : "<<testFour.getConsumedGas()<<" Gallons\n";
    
    
    return 0;
}

