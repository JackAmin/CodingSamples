//
//  main.cpp
//  ASPP#8
//
//  Created by Amin Sharif on 12-11-09.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#include <iostream>
using namespace std;
class Student{
  public:
    Student(); //default constructor.
    void inputMe(); //inputs all values.
    void outputMe();//outputs name and list of all courses
    void resetMe();//resets everything
    Student& operator=(const Student& Input);//overloaded assignment operator
    ~Student();
    
  private:
    string name;
    int numClasses;
    string *classList;
    int check;
    
};
Student::Student()
{
    name="";
    numClasses=0;

}
void Student::inputMe()
{
 //gets input from user
    cout<<"Please enter student name"<<endl;
    getline(cin,name);
    
    cout<<"Please enter number of classes"<<endl;
    cin>>numClasses;
    
    //creating a large enough arry to hold the student class list.
    classList= new string[numClasses];

    
    cin.ignore(2,'\n');// I had to google this problem, but apprently somehow counting the new line as the first input. So we just ignored it.
    
    //getting class names from user
    for(int i =0;i<numClasses;i++)
    {
        cout<<"Please enter class name:"<<endl;
        getline(cin,classList[i]);
    }
    
}
void Student::outputMe()
{
    //outputs the name and classes
    cout<<"Student Name: "<<name<<endl<<"Classes:"<<endl;
    for(int i =0;i<numClasses;i++)
    {
        cout<<classList[i]<<endl;
    }
}
void Student::resetMe()
{
    //resets everything.
    name="";
    numClasses=0;
    if(classList)
    {
        delete[] classList;
        classList=NULL;
    }
    

}
Student& Student::operator=(const Student& Input)
{
    //this is to dealloc the array we're going to stop using.

    name=Input.name;
    numClasses=Input.numClasses;
    //creates a new array and copies all the data from the Input array into it.
    classList= new string[Input.numClasses];
    for(int i=0; i<Input.numClasses;i++)
    {
        classList[i]=Input.classList[i];
    }
    return *this;
}
Student::~Student()
{
    resetMe(); 
    
}

int main(int argc, const char * argv[])
{

    //test 1:Create two students
    Student one;
    Student two;
    //test 2: Using function inputMe()
    one.inputMe();
    //test 3: Using function outputMe()
    one.outputMe();
    //test 4: Using the assignment operator
    two=one;
    two.outputMe();
    //test 5: Using function resetMe()
    one.resetMe();
    two.resetMe();

    return 0;
}

