//
//  main.cpp
//  ASPP3
//
//  Created by Amin Sharif on 12-09-13.
// 
//

//Assignment:
//write a program that will read in a length in meters and centimeters and output the equivalent length in feet and inches. Use at least three  functions: one for input,one or more for calculating, and on for output.Include a loop that lets the user repeat this computation for new input values until she says he or she wants to end the program. there are 0.3048 meters in a foot, 100 cenitmeters in a meter, and 12 inches in a foot.


#include <iostream>
using namespace std;

double input();
void calculating(double lengthIn,int& metersIn,int& centimetersIn, int& feetIn, int& inchesIn);
void output(int metersIn,int centimeters, int feetIn, int inchesIn);

int main()
{
    //repeat program var. 
    //if repeat = any integer other than 0, then the program will repeat,
    //if repeat = 0 then the program will end.
    int repeat =1;
    while(!repeat ==0)
    {
        //declaring vars
        double length =0.0;
        int feet= 0;
        int inches =0;
        int meters =0;
        int centimeters =0;
    
        //input from user
        length = input();
        
        //spliting length into meters,centimeters,feet and inches
        calculating(length,meters,centimeters,feet,inches);
        
        //display to console
        output(meters,centimeters,feet,inches);
        
        
        //repeat?
        //expecting the user will input an integer. the program will repeat if any integer other than 0 is pressed.
        
        cout<<"\n To run program again press any integer but 0, otherwise press 0 to end the program. ";
        cin>>repeat;
        cout<<endl;
    }
    return 0;
}

////reads in a length in meters/centimeters and returns it///
double input()
{
    double tempLength =0;
    cout << "EX: 5 meters and 20 centimeters is written 5.20. Please enter the length in meters.centimeters : ";
    cin>>tempLength;
    return tempLength;
    
}

////converts length into meters/centimeters and foot/inches////
//lengthIn = return value of input.
//metersIn = call by reference var for returning meters.
//centimeterIn = call by reference var for returning centimeters.
//feetIn = call by reference var for returning feet.
//inchesIn= call by reference var for returning inches.

 void calculating(double lengthIn,int& metersIn ,int& centimetersIn, int& feetIn, int& inchesIn)
{
 
    //////////////meters and centimeters//////////////
    
    //casts lengthIn into an int, removing decimal points
    metersIn=lengthIn/1;
    // I take cut off the integer numbers of lengthIn, and just leaving the fraction of a meter, which is the centimeter
    centimetersIn= static_cast<int>((lengthIn*100))%(metersIn*100);
    
    
    //////////////////feet and inches/////////////////
    
    double tempFeet =0;
    double percentage =0;
    
    tempFeet=lengthIn/0.3048;
    
    //casts tempFoot into an int, removing decimal points
    feetIn = tempFeet/1;
    
    // I take cut off the integer numbers of tempFeet, and just leaving the fraction of a feet in percentage
    percentage = static_cast<double>(static_cast<int>((tempFeet*100))%(feetIn*100))/100;
    
    //since there are 12 inches in a feet I multiply it by the percentage to get the number of inches.
    inchesIn = 12*percentage;

    
    
    
}

////Outputs to console////
//metersIn = value of Meters.
//centimeterIn = value of centimeters.
//feetIn = value of feet.
//inchesIn= value of inches.

void output(int metersIn,int centimetersIn,int feetIn, int inchesIn)
{
      
    cout<<"\n"<<metersIn<<" meters and "<<centimetersIn<<" centimeters = "<<feetIn<<" feet and "<<inchesIn<<" inches";
    
}
