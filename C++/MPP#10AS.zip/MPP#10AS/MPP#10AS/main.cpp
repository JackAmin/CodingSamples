//
//  main.cpp
//  MPP#10AS
//
//  Created by Amin Sharif on 12-12-06.
//  Copyright (c) 2012 Amin Sharif. All rights reserved.
//Write a recursive function definition for a function that has one parameter n of type int and that returns the n th Fibonacci number. The Fibonacci numbers are F 0 is 1, F 1 is 1, F 2 is 2, F 3 is 3, F 4 is 5, and in general F i+ 2 = F i + F i+ 1 for i = 0, 1, 2, ...

#include <iostream>
using namespace std;
int Fib(int n);

int main(int argc, const char * argv[])
{

    //tests
    cout<<"0th Fibonacci number: "<<Fib(0)<<endl;
    cout<<"1st Fibonacci number: "<<Fib(1)<<endl;
    cout<<"2nd Fibonacci number: "<<Fib(2)<<endl;
    cout<<"3rd Fibonacci number: "<<Fib(3)<<endl;
    cout<<"4th Fibonacci number: "<<Fib(4)<<endl;
    cout<<"5th Fibonacci number: "<<Fib(5)<<endl;
    cout<<"10th Fibonacci number: "<<Fib(10)<<endl;
    return 0;
}

int Fib(int n)
{
    //base case 
    if(n==1||n==0)
    {
        return 1;
    }
    else
    {
        //recursivly adds all the previous Fibonacci numbers until the nth Fibonnacci number
        return Fib(n-1)+Fib(n-2);
    }
}
